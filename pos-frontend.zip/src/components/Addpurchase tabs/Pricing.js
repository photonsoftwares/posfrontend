import React from "react";

const Pricing = () => {
  return <div>Sales Price</div>;
};

export default Pricing;
