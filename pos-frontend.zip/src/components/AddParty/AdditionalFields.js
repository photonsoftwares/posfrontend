import React from "react";

const AdditionalFields = () => {
  return <div>AdditionalFields</div>;
};

export default AdditionalFields;
