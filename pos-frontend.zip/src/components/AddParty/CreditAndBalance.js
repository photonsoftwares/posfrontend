import React from "react";

const CreditAndBalance = () => {
  return <div>CreditAndBalance</div>;
};

export default CreditAndBalance;
