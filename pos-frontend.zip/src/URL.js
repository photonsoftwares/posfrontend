export const BASE_Url = "http://3.111.70.84:8089/api/v1";
export const Proxy_Url = "http://3.111.70.84:8089/";
export const Email_Url = "http://3.111.70.84:8089/";
export const host = "http://3.111.70.84:8089/api/v1/";
